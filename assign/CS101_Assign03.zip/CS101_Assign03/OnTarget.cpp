#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

// TODO: define constants

// This function can be used with qsort to sort
// the elements of an array of ints.
int compare(const void *left, const void *right) {
	return *(int*)left - *(int*)right;
}

int main(void) {
	// TODO: your code here

	return 0;
}
