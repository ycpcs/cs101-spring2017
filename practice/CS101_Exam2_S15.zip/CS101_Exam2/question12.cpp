#include <stdio.h>

int main(void) {
	// IMPORTANT: do not change the code below this line
	double balances[3][2];
	// IMPORTANT: do not change the code above this line

	printf("Enter six values:\n");

	// TODO: read 6 values into the balances array

	// TODO: compute the column totals and averages

	// TODO: print the column totals and averages


	return 0;
}
